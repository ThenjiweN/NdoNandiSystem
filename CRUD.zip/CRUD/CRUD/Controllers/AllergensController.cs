﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CRUD.Models;

namespace CRUD.Controllers
{
    public class AllergensController : Controller
    {
        private NdoNandiDBEntities db = new NdoNandiDBEntities();

        // GET: Allergens
        public ActionResult Index()
        {
            return View(db.Allergens.ToList());
        }

        // GET: Allergens/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allergen allergen = db.Allergens.Find(id);
            if (allergen == null)
            {
                return HttpNotFound();
            }
            return View(allergen);
        }

        // GET: Allergens/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Allergens/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name")] Allergen allergen)
        {
            if (ModelState.IsValid)
            {
                db.Allergens.Add(allergen);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(allergen);
        }

        // GET: Allergens/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allergen allergen = db.Allergens.Find(id);
            if (allergen == null)
            {
                return HttpNotFound();
            }
            return View(allergen);
        }

        // POST: Allergens/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name")] Allergen allergen)
        {
            if (ModelState.IsValid)
            {
                db.Entry(allergen).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(allergen);
        }

        // GET: Allergens/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Allergen allergen = db.Allergens.Find(id);
            if (allergen == null)
            {
                return HttpNotFound();
            }
            return View(allergen);
        }

        // POST: Allergens/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Allergen allergen = db.Allergens.Find(id);
            db.Allergens.Remove(allergen);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
