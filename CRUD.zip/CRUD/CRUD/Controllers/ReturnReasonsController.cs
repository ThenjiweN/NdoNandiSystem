﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CRUD.Models;

namespace CRUD.Controllers
{
    [System.Web.Http.RoutePrefix("Api/condition")]
    public class ReturnReasonsController : ApiController
    {
        private NdoNandiDBEntities db = new NdoNandiDBEntities();

        [System.Web.Http.Route("read")]
        [System.Web.Mvc.HttpGet]
        // GET: api/ReturnReasons
        public IQueryable<ReturnReason> GetReturnReasons()
        {
            return db.ReturnReasons;
        }

        [System.Web.Http.Route("getById")]
        [System.Web.Mvc.HttpGet]
        // GET: api/ReturnReasons/5
        [ResponseType(typeof(ReturnReason))]
        public IHttpActionResult GetReturnReason(int id)
        {
            ReturnReason returnReason = db.ReturnReasons.Find(id);
            if (returnReason == null)
            {
                return NotFound();
            }

            return Ok(returnReason);
        }

        [System.Web.Http.Route("update")]
        [System.Web.Mvc.HttpPut]
        // PUT: api/ReturnReasons/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutReturnReason(int id, ReturnReason returnReason)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != returnReason.ID)
            {
                return BadRequest();
            }

            db.Entry(returnReason).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ReturnReasonExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [System.Web.Http.Route("create")]
        [System.Web.Mvc.HttpPost]
        // POST: api/ReturnReasons
        [ResponseType(typeof(ReturnReason))]
        public IHttpActionResult PostReturnReason(ReturnReason returnReason)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ReturnReasons.Add(returnReason);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = returnReason.ID }, returnReason);
        }

        [System.Web.Http.Route("delete")]
        [System.Web.Mvc.HttpDelete]
        // DELETE: api/ReturnReasons/5
        [ResponseType(typeof(ReturnReason))]
        public IHttpActionResult DeleteReturnReason(int id)
        {
            ReturnReason returnReason = db.ReturnReasons.Find(id);
            if (returnReason == null)
            {
                return NotFound();
            }

            db.ReturnReasons.Remove(returnReason);
            db.SaveChanges();

            return Ok(returnReason);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ReturnReasonExists(int id)
        {
            return db.ReturnReasons.Count(e => e.ID == id) > 0;
        }
    }
}