﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CRUD.Models;

namespace CRUD.Controllers
{
    public class BlogEntriesController : ApiController
    {
        private NdoNandiDBEntities db = new NdoNandiDBEntities();

        // GET: api/BlogEntries
        public IQueryable<BlogEntry> GetBlogEntries()
        {
            return db.BlogEntries;
        }

        // GET: api/BlogEntries/5
        [ResponseType(typeof(BlogEntry))]
        public IHttpActionResult GetBlogEntry(int id)
        {
            BlogEntry blogEntry = db.BlogEntries.Find(id);
            if (blogEntry == null)
            {
                return NotFound();
            }

            return Ok(blogEntry);
        }

        // PUT: api/BlogEntries/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBlogEntry(int id, BlogEntry blogEntry)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != blogEntry.ID)
            {
                return BadRequest();
            }

            db.Entry(blogEntry).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BlogEntryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/BlogEntries
        [ResponseType(typeof(BlogEntry))]
        public IHttpActionResult PostBlogEntry(BlogEntry blogEntry)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.BlogEntries.Add(blogEntry);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = blogEntry.ID }, blogEntry);
        }

        // DELETE: api/BlogEntries/5
        [ResponseType(typeof(BlogEntry))]
        public IHttpActionResult DeleteBlogEntry(int id)
        {
            BlogEntry blogEntry = db.BlogEntries.Find(id);
            if (blogEntry == null)
            {
                return NotFound();
            }

            db.BlogEntries.Remove(blogEntry);
            db.SaveChanges();

            return Ok(blogEntry);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BlogEntryExists(int id)
        {
            return db.BlogEntries.Count(e => e.ID == id) > 0;
        }
    }
}