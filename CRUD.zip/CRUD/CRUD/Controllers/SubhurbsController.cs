﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CRUD.Models;

namespace CRUD.Controllers
{
    [System.Web.Http.RoutePrefix("Api/condition")]
    public class SubhurbsController : ApiController
    {
        private NdoNandiDBEntities db = new NdoNandiDBEntities();

        [System.Web.Http.Route("read")]
        [System.Web.Mvc.HttpGet]
        // GET: api/Subhurbs
        public IQueryable<Subhurb> GetSubhurbs()
        {
            return db.Subhurbs;
        }

        [System.Web.Http.Route("getById")]
        [System.Web.Mvc.HttpGet]
        // GET: api/Subhurbs/5
        [ResponseType(typeof(Subhurb))]
        public IHttpActionResult GetSubhurb(int id)
        {
            Subhurb subhurb = db.Subhurbs.Find(id);
            if (subhurb == null)
            {
                return NotFound();
            }

            return Ok(subhurb);
        }

        [System.Web.Http.Route("update")]
        [System.Web.Mvc.HttpPut]
        // PUT: api/Subhurbs/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSubhurb(int id, Subhurb subhurb)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != subhurb.SubhurbID)
            {
                return BadRequest();
            }

            db.Entry(subhurb).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SubhurbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [System.Web.Http.Route("create")]
        [System.Web.Mvc.HttpPost]
        // POST: api/Subhurbs
        [ResponseType(typeof(Subhurb))]
        public IHttpActionResult PostSubhurb(Subhurb subhurb)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Subhurbs.Add(subhurb);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = subhurb.SubhurbID }, subhurb);
        }

        [System.Web.Http.Route("delete")]
        [System.Web.Mvc.HttpDelete]
        // DELETE: api/Subhurbs/5
        [ResponseType(typeof(Subhurb))]
        public IHttpActionResult DeleteSubhurb(int id)
        {
            Subhurb subhurb = db.Subhurbs.Find(id);
            if (subhurb == null)
            {
                return NotFound();
            }

            db.Subhurbs.Remove(subhurb);
            db.SaveChanges();

            return Ok(subhurb);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SubhurbExists(int id)
        {
            return db.Subhurbs.Count(e => e.SubhurbID == id) > 0;
        }
    }
}